package com.cg.banking.bankingservices;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public interface BankingServices {
	Account openAccount(String accountType,float initBalance);
	float depositAmount(long accountNo,float amount);
	float withdrawAmount(long accountNo,float amount);
	boolean fundTransfer(long accountNoFrom,long accountNoTo,float transferAmount);
	Account getAccountDetails(long accountNo);
	List<Account> getAllAccountDetails();
	List<Transaction> getAccountAllTransaction(long accountNo);
}