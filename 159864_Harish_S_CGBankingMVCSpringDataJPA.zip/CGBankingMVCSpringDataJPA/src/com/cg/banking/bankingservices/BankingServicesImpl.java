package com.cg.banking.bankingservices;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.dao.AccountDAO;
import com.cg.banking.dao.TransactionDAO;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {

	@Autowired
	AccountDAO accountDao;
	@Autowired
	TransactionDAO transactionDao;
	
	@Override
	public Account openAccount(String accountType, float initBalance) {
		Account account = new Account();
		account.setAccountType(accountType);
		account.setAccountBalance(initBalance);
		return accountDao.save(account);
	}

	@Override
	public float depositAmount(long accountNo, float amount){
		Account account = accountDao.findById(accountNo).get();
		account.setAccountBalance(account.getAccountBalance()+amount);
		accountDao.save(account);
		Transaction transaction = new Transaction(amount, "Deposit", account);
		transactionDao.save(transaction);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount) {
		Account account = accountDao.findById(accountNo).get();
		account.setAccountBalance(account.getAccountBalance()-amount);
		accountDao.save(account);
		Transaction transaction = new Transaction(amount, "Withdraw", account);
		transactionDao.save(transaction);
		return account.getAccountBalance();	
	}

	@Override
	public boolean fundTransfer(long accountNoFrom, long accountNoTo, float transferAmount) {
		Account accountFrom = accountDao.findById(accountNoFrom).get();
		Account accountTo = accountDao.findById(accountNoTo).get();
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		accountDao.save(accountTo);
		accountDao.save(accountFrom);
		transactionDao.save(new Transaction(transferAmount, "Fund Transfer", accountFrom));
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) {
		return accountDao.findById(accountNo).get();
	}

	@Override
	public List<Account> getAllAccountDetails(){
		return accountDao.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		Account account = accountDao.findById(accountNo).get();
		return transactionDao.findAccountAllTransactions(account);
	}
}