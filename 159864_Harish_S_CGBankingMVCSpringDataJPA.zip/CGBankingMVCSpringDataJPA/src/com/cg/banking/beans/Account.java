package com.cg.banking.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private long accountNo;
	@Min(value=0)
	private float accountBalance;
	@NotEmpty(message="I am getting violated- accountType")
	private String accountType;
	@OneToMany(mappedBy="account")
	private List<Transaction> transactions;
	
	//Parameter Constructor
	public Account(int accountNo, int accountBalance, String accountType) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
	}
	//Default Constructor

	public Account() {
		super();
		this.accountType="Savings";
	}
	//GnS

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", accountBalance="
				+ accountBalance + ", accountType=" + accountType;
	}
	
}
