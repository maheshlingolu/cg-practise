package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.bankingservices.BankingServices;
import com.cg.banking.beans.Account;

@Controller
public class AccountDisplayController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/displayAccountDetails")
	public ModelAndView getAccountDetails(@RequestParam("accountNo") long accountNo) {
		Account account = bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("accountDetailsPage", "account", account);
	}
}
