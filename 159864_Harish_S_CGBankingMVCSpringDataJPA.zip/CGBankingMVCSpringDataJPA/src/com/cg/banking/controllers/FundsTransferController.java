package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.bankingservices.BankingServices;

@Controller
public class FundsTransferController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/transferFunds")
	public ModelAndView transferFunds(@RequestParam("senderAccountNo") long accountNoFrom,
			@RequestParam("receiverAccountNo") long accountNoTo,@RequestParam("transferAmount") float transferAmount) {
			return new ModelAndView
					("fundsTransferStatusPage", "transferStatus",bankingServices.fundTransfer(accountNoFrom, accountNoTo, transferAmount));
	}
}