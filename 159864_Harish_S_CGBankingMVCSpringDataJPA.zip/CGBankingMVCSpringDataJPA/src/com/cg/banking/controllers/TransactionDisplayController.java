package com.cg.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.bankingservices.BankingServices;
import com.cg.banking.beans.Transaction;

@Controller
public class TransactionDisplayController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/displayTransactionDetails")
	public ModelAndView getTransactionDetails(@RequestParam("accountNo") long accountNo) {
		List<Transaction> transactions = bankingServices.getAccountAllTransaction(accountNo); 
		return new ModelAndView("transactionDetailsPage","transactions", transactions);
	}
}
