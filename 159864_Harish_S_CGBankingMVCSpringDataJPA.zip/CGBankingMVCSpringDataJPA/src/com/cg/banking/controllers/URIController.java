package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;

@Controller
public class URIController {
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/createAccount")
	public String getAccountCreationPage() {
		return "createAccountPage";
	}
	@ModelAttribute("account")
	public Account getNewAccount() {
		return new Account();
	}
	@RequestMapping("/deposit")
	public String getDepositPage() {
		return "depositPage";
	}
	@RequestMapping("/withdraw")
	public String getWithdrawPage() {
		return "withdrawPage";
	}
	@RequestMapping("/fundsTransfer")
	public String getFundsTransferPage() {
		return "fundsTransferPage";
	}
	@RequestMapping("/getAccountDetails")
	public String getAccountDetails() {
		return "accountDetailsPage";
	}
	@RequestMapping("/getTransactionDetails")
	public String getTransactionDetails() {
		return "transactionDetailsPage";
	}
}
