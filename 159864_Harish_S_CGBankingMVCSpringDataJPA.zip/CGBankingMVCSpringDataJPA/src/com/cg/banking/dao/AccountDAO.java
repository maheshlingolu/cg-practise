package com.cg.banking.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.Account;
public interface AccountDAO extends JpaRepository<Account, Long>{
	/*long save(Account account) ;
	boolean update(Account account) ;
	Account findOne(long accountNo) ;
	List<Account> findAllAccounts() ;
	List<Transaction> findAllTransactions(long accountNo) ;
	int transactionUpdate(Transaction transaction);*/
}