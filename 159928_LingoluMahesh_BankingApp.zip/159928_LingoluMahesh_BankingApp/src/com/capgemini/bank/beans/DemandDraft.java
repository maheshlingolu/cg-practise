package com.capgemini.bank.beans;
public class DemandDraft {
	private int transaction_id,dd_commission;
	private long dd_amount;
	private String customer_name ,date,in_favor_of,ddDescription ;
	private long phone_number;
	
	public DemandDraft() {
		super();
	}

	public DemandDraft(int transaction_id, int dd_commission, long dd_amount,
			String customer_name, String in_favor_of, String ddDescription,
			long phone_number) {
		super();
		this.transaction_id = transaction_id;
		this.dd_commission = dd_commission;
		this.dd_amount = dd_amount;
		this.customer_name = customer_name;
		this.date=date;
		this.in_favor_of = in_favor_of;
		this.ddDescription = ddDescription;
		this.phone_number = phone_number;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

	public int getDd_commission() {
		return dd_commission;
	}

	public void setDd_commission(int dd_commission) {
		this.dd_commission = dd_commission;
	}

	public long getDd_amount() {
		return dd_amount;
	}

	public void setDd_amount(long dd_amount) {
		this.dd_amount = dd_amount;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getIn_favor_of() {
		return in_favor_of;
	}

	public void setIn_favor_of(String in_favor_of) {
		this.in_favor_of = in_favor_of;
	}

	public String getDdDescription() {
		return ddDescription;
	}

	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}

	public long getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(long phone_number) {
		this.phone_number = phone_number;
	}

	@Override
	public String toString() {
		return "DemandDraft [transaction_id=" + transaction_id
				+ ", dd_commission=" + dd_commission + ", dd_amount="
				+ dd_amount + ", customer_name=" + customer_name + ", date="
				+ date + ", in_favor_of=" + in_favor_of + ", ddDescription="
				+ ddDescription + ", phone_number=" + phone_number + "]";
	}
}