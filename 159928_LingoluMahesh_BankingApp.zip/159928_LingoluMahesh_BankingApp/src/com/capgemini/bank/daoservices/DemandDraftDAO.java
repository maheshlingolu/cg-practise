package com.capgemini.bank.daoservices;
import java.sql.SQLException;
import com.capgemini.bank.beans.DemandDraft;
public interface DemandDraftDAO {
	DemandDraft save(DemandDraft demandDraft) throws SQLException;
	DemandDraft getDemandDraftDetails(int transactionId) throws SQLException;
}
