package com.capgemini.bank.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.bank.beans.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;
public class DemandDraftDAOServicesImpl implements DemandDraftDAO{
	private static final Logger logger = Logger.getLogger(DemandDraftDAO.class);
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public DemandDraft save(DemandDraft demandDraft) throws SQLException {
		try
		{
			conn.setAutoCommit(false);
			PreparedStatement pstmt = conn.prepareStatement("insert into demand_draft (transaction_id, customer_name, in_favor_of, phone_number, date_of_transaction, "
					+ "dd_amount, dd_commission, dd_description) values (transaction_id_seq.nextval,?,?,?,TO_DATE(?,'dd-MON-yy'),?,?,?)");
			pstmt.setString(1, demandDraft.getCustomer_name());
			pstmt.setString(2, demandDraft.getIn_favor_of());
			pstmt.setLong(3, demandDraft.getPhone_number());
			pstmt.setString(4, demandDraft.getDate());
			pstmt.setLong(5, demandDraft.getDd_amount());
			pstmt.setInt(6, demandDraft.getDd_commission());
			pstmt.setString(7, demandDraft.getDdDescription());
			pstmt.executeUpdate();

			PreparedStatement pstmt1 =conn.prepareStatement("select max(transaction_id) from demand_draft"); 
			ResultSet rs = pstmt1.executeQuery();
			rs.next();
			demandDraft.setTransaction_id(rs.getInt(1));
			conn.commit();
			return demandDraft;
		}
		catch(SQLException e){
			logger.error(e.getMessage()+" "+e.getErrorCode()+" ");
			System.out.println("Record not inserted");
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	}

