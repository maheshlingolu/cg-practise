package com.capgemini.bank.main;
import com.capgemini.bank.util.ConnectionProvider;
public class ConnectionTest {
	public static void main(String[] args){
		if (ConnectionProvider.getDBConnection()!=null)
			System.out.println("Im in");
		else
			System.out.println("nope"); 
	}
}
