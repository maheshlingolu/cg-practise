package com.capgemini.bank.main;

import java.util.Scanner;

import com.capgemini.bank.exceptions.DemandDraftServiceDownException;
import com.capgemini.bank.exceptions.InvalidAmountException;
import com.capgemini.bank.services.DemandDraftServices;
import com.capgemini.bank.services.DemandDraftServicesImpl;

public class MainClass {
public static void main(String[] args) throws InvalidAmountException, DemandDraftServiceDownException{
	DemandDraftServices services = new DemandDraftServicesImpl();
	int ch;
	do{
		System.out.println("Enter your option");
		
		System.out.println("1.Enter Demand Draft Details : \n2.Exit");
		ch = new Scanner(System.in).nextInt();
		switch(ch){	
		case 1:
			System.out.println("Enter the name of the customer");
			String customer_name= new Scanner(System.in).next();
			System.out.println("Enter customer phone Number");
			int phone_number= new Scanner(System.in).nextInt();
			System.out.println("in favor of");
			String in_favor_of= new Scanner(System.in).next();
			System.out.println("Enter Demand Draft amount (inRs)");
			int dd_amount= new Scanner(System.in).nextInt();
			System.out.println("Enter Remarks");
			String dd_description= new Scanner(System.in).next();
			
			long demandDraft= services.DemandDraft
			break;
		case 2:	System.out.println("Exiting..."); break;
		default: System.out.println("Invalid choice!");break;
		}
	}while(ch!=2);		
}
}
