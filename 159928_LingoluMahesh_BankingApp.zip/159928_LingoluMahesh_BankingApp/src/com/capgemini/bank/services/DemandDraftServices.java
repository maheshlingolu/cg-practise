package com.capgemini.bank.services;
import com.capgemini.bank.exceptions.DemandDraftServiceDownException;
import com.capgemini.bank.exceptions.InvalidAmountException;
import com.capgemini.bank.beans.*;
public interface DemandDraftServices {
	int addDemandDraftDetails(DemandDraft demandDraft) throws DemandDraftServiceDownException;
	DemandDraft getDemandDraftDetails(int transactionId) throws DemandDraftServiceDownException;
}
