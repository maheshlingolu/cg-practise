package com.capgemini.bank.services;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import oracle.sql.DATE;

import com.capgemini.bank.beans.*;
import com.capgemini.bank.daoservices.DemandDraftDAO;
import com.capgemini.bank.daoservices.DemandDraftDAOServicesImpl;
import com.capgemini.bank.exceptions.DemandDraftServiceDownException;
import com.capgemini.bank.exceptions.InvalidAmountException;
public class DemandDraftServicesImpl implements DemandDraftServices{
DemandDraftDAO demandDraftDAO= new DemandDraftDAOServicesImpl();
private static final Logger logger = Logger.getLogger(DemandDraftDAO.class);
@Override
public int addDemandDraftDetails(DemandDraft demandDraft)
		throws DemandDraftServiceDownException {
	try {
		
		//dd amount check and set
		if(demandDraft.getDd_amount()<0)
			throw new InvalidDDAmountException("Negative DD Amount entered");
		if(demandDraft.getDd_amount()<=5000)
			demandDraft.setDdCommission(10);
		else if(demandDraft.getDd_amount()>5000 && demandDraft.getDd_amount()<=10000)
			demandDraft.setDdCommission(41);
		else if(demandDraft.getDd_amount()>10000 && demandDraft.getDd_amount()<=100000)
			demandDraft.setDdCommission(51);
		else if(demandDraft.getDd_amount()>100000 && demandDraft.getDd_amount()<=500000)
			demandDraft.setDdCommission(306);
		else
			throw new InvalidDDAmountException("DD Amount above 5 lakhs");
		
		//phone number check
		if(demandDraft.getPhoneNo().length()>10)
			throw new InvalidPhoneNumberException("Phone number is longer than 10 digits");
		
		//SettingDate
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		demandDraft.setDate(format.format(new Date()));
		return demandDraftDAO.addDemandDraftDetails(demandDraft);

	} catch (SQLException e) {
		logger.error(e.getMessage()+" "+e.getErrorCode()+" ");
		throw new BankingServicesDownException();
	} catch (InvalidDDAmountException e) {
		logger.error(e.getMessage());
		System.out.println("DD Amount should be positive and below 5 lakhs");
		throw new BankingServicesDownException();
	}catch(InvalidPhoneNumberException e){
		logger.error(e.getMessage());
		System.out.println("Phone Number is invalid");
		throw new BankingServicesDownException();
	}
}

@Override
public DemandDraft getDemandDraftDetails(int transactionId)
		throws DemandDraftServiceDownException {
	// TODO Auto-generated method stub
	return null;
}

}

