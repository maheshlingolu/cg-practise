package com.capgemini.bank.test;

public class DemandDraftTest {

}
