package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {
	private String  name,favor,remarks;
	private long phone;
	private int amount;
	private Date date;
	
	
	public DemandDraft() {
		super();
	}


	public DemandDraft(String name, String favor, String remarks, long phone,
			int amount) {
		super();
		this.name = name;
		this.favor = favor;
		this.remarks = remarks;
		this.phone = phone;
		this.amount = amount;
		//this.date=date;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getFavor() {
		return favor;
	}


	public void setFavor(String favor) {
		this.favor = favor;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public long getPhone() {
		return phone;
	}


	public void setPhone(long phone) {
		this.phone = phone;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}
	


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + ((favor == null) ? 0 : favor.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + (int) (phone ^ (phone >>> 32));
		result = prime * result + ((remarks == null) ? 0 : remarks.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DemandDraft other = (DemandDraft) obj;
		if (amount != other.amount)
			return false;
		if (favor == null) {
			if (other.favor != null)
				return false;
		} else if (!favor.equals(other.favor))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phone != other.phone)
			return false;
		if (remarks == null) {
			if (other.remarks != null)
				return false;
		} else if (!remarks.equals(other.remarks))
			return false;
		return true;
	}
	
	
	
}
