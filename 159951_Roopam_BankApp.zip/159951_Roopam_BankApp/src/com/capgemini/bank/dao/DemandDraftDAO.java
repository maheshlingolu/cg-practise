package com.capgemini.bank.dao;

import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class DemandDraftDAO implements IDemandDraftDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger = Logger.getLogger(DemandDraftDAO.class);

	@Override
	public int addDemandDraftdetails(DemandDraft demandDraft) throws SQLException {
		try {
			conn.setAutoCommit(false);
			int com=0,n=demandDraft.getAmount();
			if (n<=5000)
				com=10;
			else if (n>5000 && n<=10000)
				com=41;
			else if(n>10000 && n<100000)
				com=51;
			else if (n>100000 && n<500000)
				com=306; 
			SimpleDateFormat dateFormat= new SimpleDateFormat("dd-MMM-yyyy");
			Date date=new Date();
			String sql="INSERT INTO demand_draft (transaction_id,customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description) VALUES (Transaction_Id_Seq.NEXTVAL,?,?,?,?,?,?,?)";
			PreparedStatement pstmt1=conn.prepareStatement(sql);
			pstmt1.setString(1, demandDraft.getName());
			pstmt1.setString(2, demandDraft.getFavor());
			pstmt1.setLong(3, demandDraft.getPhone());
			pstmt1.setString(4, dateFormat.format(date));
			pstmt1.setInt(5, demandDraft.getAmount());
			pstmt1.setInt(6, com);
			pstmt1.setString(7,demandDraft.getRemarks());
			pstmt1.executeUpdate();
			
			sql="Select max(transaction_id) from demand_draft";
			PreparedStatement pstmt2= conn.prepareStatement(sql);
			ResultSet rs= pstmt2.executeQuery();
			rs.next();
			int id=rs.getInt(1);
			
			conn.commit();
			return id;
		} catch (SQLException e) {
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		String sql="Select * from demand_draft where transaction_id="+transactionId;
		PreparedStatement pstmt1= conn.prepareStatement(sql);
		ResultSet rs= pstmt1.executeQuery();
		if (rs.next())
			return new DemandDraft(rs.getString("customer_name"), rs.getString("in_favor_of"), rs.getString("dd_description"), rs.getLong("phone_number"), rs.getInt("dd_amount"));
		return null;
	}

}
