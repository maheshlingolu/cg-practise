package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.InvalidAmountException;
import com.capgemini.bank.exception.InvalidPhoneNumberException;


public class DemandDraftService implements IDemandDraftService{
	private IDemandDraftDAO ddDAO=new DemandDraftDAO();
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingServicesDownException, InvalidPhoneNumberException, InvalidAmountException{
		long phone=demandDraft.getPhone();
		int i=0;
		while(phone!=0){
			phone/=10;
			i++;
		}
		if (i!=10)
			throw new InvalidPhoneNumberException();
		if(demandDraft.getAmount()>500000)
			throw new InvalidAmountException();
		return ddDAO.addDemandDraftdetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException,BankingServicesDownException {
		return ddDAO.getDemandDraftDetails(transactionId);
	}

}
