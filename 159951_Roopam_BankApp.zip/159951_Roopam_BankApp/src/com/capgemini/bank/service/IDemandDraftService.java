package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.InvalidAmountException;
import com.capgemini.bank.exception.InvalidPhoneNumberException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException,BankingServicesDownException, InvalidPhoneNumberException, InvalidAmountException;
	DemandDraft getDemandDraftDetails(int transactionId) throws SQLException, BankingServicesDownException;
}
