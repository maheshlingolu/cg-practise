package com.capgemini.bank.testcases;

import com.capgemini.bank.service.DemandDraftService;

public class BankingJUnit {
	private static DemandDraftService demandDraftService;
	
	//@BeforeClass
	public static void setUpTestEnv(){
		demandDraftService = new DemandDraftService();
	}	
	//@Before
	public void setUpMockDataForTest(){
		System.out.println("Start");
	}
}
