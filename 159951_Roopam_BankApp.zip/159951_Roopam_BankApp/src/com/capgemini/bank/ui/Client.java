package com.capgemini.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.InvalidAmountException;
import com.capgemini.bank.exception.InvalidPhoneNumberException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	public static void main(String[] args) {
		int n=0;
		Scanner sc= new Scanner(System.in);

		try {
			while(true){
				System.out.println("Menu:\n1. Enter Demand Draft Details\n2. Exit");
				n=sc.nextInt();
				if (n==1){
					System.out.println("Enter the name of the customer:");
					String name=sc.next();
					System.out.println("Enter customer phone number:");
					long phone=sc.nextLong();
					System.out.println("In favor of:");
					String favor=sc.next();
					System.out.println("Enter Demand Draft amount (in Rs):");
					int amount= sc.nextInt();
					System.out.println("Enter Remarks:");
					String remarks= sc.next().toString();
					DemandDraft demandDraft= new DemandDraft(name, favor, remarks, phone, amount);
					IDemandDraftService service= new DemandDraftService();
					System.out.println("Your Demand Draft request has been successfully registered along with the "+service.addDemandDraftDetails(demandDraft));
				}
				else if (n==2)
					break;
				else
					System.out.println("Invalid choice");
			}
		} catch (SQLException |BankingServicesDownException e) {
			System.out.println("Banking Services down, try again later.");
			e.printStackTrace();
		} catch (InvalidPhoneNumberException e) {
			System.out.println("Invalid phone number");
			e.printStackTrace();
		} catch (InvalidAmountException e) {
			System.out.println("Amount exceeding the allowed limit.");
			e.printStackTrace();
		}
	}
}


