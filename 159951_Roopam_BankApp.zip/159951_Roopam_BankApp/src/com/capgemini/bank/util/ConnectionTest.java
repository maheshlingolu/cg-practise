package com.capgemini.bank.util;

public class ConnectionTest {
	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection made");
		else 
			System.out.println("Not connected ");
	}
}
