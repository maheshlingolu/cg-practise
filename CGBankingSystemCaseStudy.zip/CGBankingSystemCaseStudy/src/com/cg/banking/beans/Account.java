package com.cg.banking.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Account {
	private int pinNumber,confirmPinNumber;
	private String firstName,lastName;
	private long phoneNumber;
	private String accountType;
	private float accountBalance;
	@Id
	@SequenceGenerator(name="account_seq",initialValue=1111,allocationSize=1,sequenceName="account_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="account_seq")
	private long accountNo;
	@OneToMany(mappedBy="account")
	private List<Transaction> transactions;
	public Account(int pinNumber, int confirmPinNumber, String firstName,
			String lastName, long phoneNumber, String accountType,
			float accountBalance, long accountNo, List<Transaction> transactions) {
		super();
		this.pinNumber = pinNumber;
		this.confirmPinNumber = confirmPinNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transactions = transactions;
	}
	public Account(int pinNumber, int confirmPinNumber, String firstName,
			String lastName, long phoneNumber, String accountType,
			float accountBalance) {
		super();
		this.pinNumber = pinNumber;
		this.confirmPinNumber = confirmPinNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account() {
		super();
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getConfirmPinNumber() {
		return confirmPinNumber;
	}
	public void setConfirmPinNumber(int confirmPinNumber) {
		this.confirmPinNumber = confirmPinNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	@Override
	public String toString() {
		return "pinNumber=" + pinNumber + ", confirmPinNumber="
				+ confirmPinNumber + ", firstName=" + firstName + ", lastName="
				+ lastName + ", phoneNumber=" + phoneNumber + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", accountNo=" + accountNo ;
	}




}