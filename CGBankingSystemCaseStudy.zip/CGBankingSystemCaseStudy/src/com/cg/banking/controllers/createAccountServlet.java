package com.cg.banking.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/createAccount")
public class createAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public createAccountServlet() {
		super();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices services=new BankingServicesImpl();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		long phoneNumber=Long.parseLong(request.getParameter("phoneNumber"));
		float accountBalance=Float.parseFloat(request.getParameter("accountBalance"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		int confirmPinNumber=Integer.parseInt(request.getParameter("confirmPinNumber"));
		String accountType=request.getParameter("accountType");
		if(confirmPinNumber!=pinNumber){
			request.setAttribute("errorMessage","Pin is not matching");
			RequestDispatcher dispatcher=request.getRequestDispatcher("createAccountPage.jsp");
			dispatcher.forward(request, response);
		}
		long accountNo;
		try {
		
			accountNo = services.openAccount(accountType, accountBalance, pinNumber, confirmPinNumber, firstName, lastName, phoneNumber);
			request.setAttribute("accountNo",accountNo);

		} catch (InvalidAmountException e) {
			request.setAttribute("errorMessage1","Initial Balance Should be greater than 1000 Rupees.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("createAccountPage.jsp");
			dispatcher.forward(request, response);
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayAccountNo.jsp");
		dispatcher.forward(request, response);
	}
}
