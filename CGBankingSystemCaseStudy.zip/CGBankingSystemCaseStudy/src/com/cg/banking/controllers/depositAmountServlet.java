package com.cg.banking.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/depositAmount")
public class depositAmountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
public depositAmountServlet() {
		super();
	}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices services=new BankingServicesImpl();
		long accountNo=Long.parseLong(request.getParameter("accountNo"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		float accountBalance;
		try {
			accountBalance = services.depositAmount(accountNo, amount);
			request.setAttribute("amount", amount);
			request.setAttribute("accountBalance",accountBalance);
		} catch (AccountNotFoundException e) {
			request.setAttribute("errorMessage","Account not found.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("depositPage.jsp");
			dispatcher.forward(request, response);
		} catch (InvalidAmountException e) {
			request.setAttribute("errorMessage","Enter a valid amount.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("depositPage.jsp");
			dispatcher.forward(request, response);
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayDeposit.jsp");
		dispatcher.forward(request, response);

	}

}
