package com.cg.banking.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/fundTransfer")
public class fundTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public fundTransferServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices services=new BankingServicesImpl();
		long accountNoFrom=Long.parseLong(request.getParameter("accountNoFrom"));
		long accountNoTo=Long.parseLong(request.getParameter("accountNoTo"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		float accountBalance;
		try {
			accountBalance = services.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber);
			request.setAttribute("amount", amount);
			request.setAttribute("accountNoTo", accountNoTo);
			request.setAttribute("accountBalance",accountBalance);
		} catch (AccountNotFoundException e) {
			request.setAttribute("errorMessage","Account not found.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundTransferPage.jsp");
			dispatcher.forward(request, response);
		} catch (InsufficientBalanceException e) {
			request.setAttribute("errorMessage1","Insufficient Account Balance.Minimum 1000 Rupees should be present in account");
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundTransferPage.jsp");
			dispatcher.forward(request, response);
		}catch (InvalidPinNumberException e) {
			request.setAttribute("errorMessage1","Invalid Pin Number");
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundTransferPage.jsp");
			dispatcher.forward(request, response);
		} catch (InvalidAmountException e) {
			request.setAttribute("errorMessage1","Enter a valid amount.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundTransferPage.jsp");
			dispatcher.forward(request, response);
		}

		RequestDispatcher dispatcher=request.getRequestDispatcher("displayFundTransfer.jsp");
		dispatcher.forward(request, response);
	}

}
