package com.cg.banking.controllers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/getAccountDetails")
public class getAccountDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public getAccountDetailsServlet() {
        super();
    }
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices services=new BankingServicesImpl();
		long accountNo=Long.parseLong(request.getParameter("accountNo"));
		 Account account;
		try {
			account = services.getAccountDetails(accountNo);
			request.setAttribute("account", account);
		} catch (AccountNotFoundException e) {
			request.setAttribute("errorMessage","Account not found.");
			RequestDispatcher dispatcher=request.getRequestDispatcher("displayAccountPage.jsp");
			dispatcher.forward(request, response);
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayAccountDetails.jsp");
		dispatcher.forward(request, response);
	}
}
