package com.cg.banking.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/withdraw")
public class withdrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   public withdrawServlet() {
        super();
    }
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices services=new BankingServicesImpl();
		long accountNo=Long.parseLong(request.getParameter("accountNo"));
	    float amount=Float.parseFloat(request.getParameter("amount"));
	    int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
	    float accountBalance;
		try {
			accountBalance = services.withdrawAmount(accountNo, amount, pinNumber);
			request.setAttribute("amount", amount);
		    request.setAttribute("accountBalance",accountBalance); 
		} catch (AccountNotFoundException e) {
		    request.setAttribute("errorMessage","Account not found.");
		    RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawPage.jsp");
			dispatcher.forward(request, response);
		} catch (InsufficientBalanceException e) {
			request.setAttribute("errorMessage2","Insufficient Account Balance.Minimum 1000 Rupees should be present in account");
		    RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawPage.jsp");
			dispatcher.forward(request, response);
		} catch (InvalidPinNumberException e) {
			request.setAttribute("errorMessage1","Invalid Pin Number");
		    RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawPage.jsp");
		    dispatcher.forward(request, response);
		} catch (InvalidAmountException e) {
			request.setAttribute("errorMessage3","Invalid Amount. Amount should be greater than 100");
		    RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawPage.jsp");
		    dispatcher.forward(request, response);
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayWithdraw.jsp");
		dispatcher.forward(request, response);
	    
	}

}
