package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface AccountDAO {
	Account saveAccountDetails(Account account);
	Account getAccountDetails(long accountNo);
	boolean updateTransaction(Transaction transaction);
	boolean updateAccount(Account account);
	ArrayList<Transaction> getAccountAllTransactionDetails(Account account);
	ArrayList<Account> getAllAccountDetails();

	
	
}