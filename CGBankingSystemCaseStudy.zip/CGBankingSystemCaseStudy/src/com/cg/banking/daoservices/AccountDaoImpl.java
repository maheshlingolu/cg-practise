package com.cg.banking.daoservices;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.EntityManagerFactoryProvider;
public class AccountDaoImpl implements AccountDAO{
	EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();
	@Override
	public Account saveAccountDetails(Account account) {
		EntityManager entitymanager=factory.createEntityManager();
		entitymanager.getTransaction().begin();
		entitymanager.persist(account);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return account;
	}
	@Override
	public Account getAccountDetails(long accountNo) {
		EntityManager entitymanager=factory.createEntityManager();
		return entitymanager.find(Account.class, accountNo);
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransactionDetails(Account account) {
		EntityManager entitymanager=factory.createEntityManager();
		Query query=entitymanager.createNamedQuery("getAllTransactions");
		query.setParameter("account", account);
		@SuppressWarnings("unchecked")
		ArrayList<Transaction> list=(ArrayList<Transaction>) query.getResultList();
		return list;
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() {
		EntityManager entitymanager=factory.createEntityManager();
		Query query=entitymanager.createNamedQuery("from Account a");
		@SuppressWarnings("unchecked")
		ArrayList<Account> list=(ArrayList<Account>) query.getResultList();
		return list;
	}
	@Override
	public boolean updateTransaction(Transaction transaction) {
		EntityManager entitymanager=factory.createEntityManager();
		entitymanager.getTransaction().begin();
		entitymanager.merge(transaction);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return true;
	}
	@Override
	public boolean updateAccount(Account account) {
		EntityManager entitymanager=factory.createEntityManager();
		entitymanager.getTransaction().begin();
		entitymanager.merge(account);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return true;
	}	
}
