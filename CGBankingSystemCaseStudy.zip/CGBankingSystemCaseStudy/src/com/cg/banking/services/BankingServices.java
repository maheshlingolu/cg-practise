package com.cg.banking.services;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.NoTransactionsFoundException;
public interface BankingServices {
	long  openAccount(String accountType,float accountBalance,int pinNumber,int confirmPinNumber,String firstName,String lastName,long phoneNumber) throws InvalidAmountException;
	float depositAmount(long accountNo,float amount) throws AccountNotFoundException, InvalidAmountException;
	float withdrawAmount(long accountNo,float amount,int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, InvalidAmountException;
	float fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, InvalidAmountException;
	Account getAccountDetails(long accountNo) throws AccountNotFoundException;
	ArrayList<Account> getAllAccountDetails();
	ArrayList<Transaction> getAccountAllTransaction(Account account) throws NoTransactionsFoundException;
}