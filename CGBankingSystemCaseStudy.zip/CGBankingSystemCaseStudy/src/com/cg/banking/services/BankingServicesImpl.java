package com.cg.banking.services;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.NoTransactionsFoundException;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountdao=new AccountDaoImpl();

	@Override
	public float depositAmount(long accountNo, float amount) throws AccountNotFoundException, InvalidAmountException {
		Account account;
		if(accountdao.getAccountDetails(accountNo)==null)
			throw new AccountNotFoundException();
		else{
			account = getAccountDetails(accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			if(amount>0){
				accountdao.updateAccount(account);
				Transaction transaction=new Transaction(amount,"deposit",account);
				accountdao.updateTransaction(transaction);
				return account.getAccountBalance();
			}
			else
				throw new InvalidAmountException();
		}
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, InvalidAmountException {
		Account account;
		account = getAccountDetails(accountNo);
		if(amount<=100)
			throw new InvalidAmountException();
		if(account.getPinNumber()==pinNumber){
			if(account.getAccountBalance()-amount>1000){
				account.setAccountBalance(account.getAccountBalance()-amount);
				accountdao.updateAccount(account);
				Transaction transaction1=new Transaction(amount,"withdraw",account);
				accountdao.updateTransaction(transaction1);
			}
			else{
				throw new InsufficientBalanceException();
			}
			return account.getAccountBalance();
		}
		else throw new InvalidPinNumberException();

	}
	@Override
	public float fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, InvalidAmountException{
		Account account1;
		account1 = getAccountDetails(accountNoTo);
		Account account2=getAccountDetails(accountNoFrom);
		if(account2.getPinNumber()==pinNumber){
			if(account2.getAccountBalance()-transferAmount>1000){
				if(transferAmount>0){
					account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
					account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
					accountdao.updateAccount(account1);
					Transaction transaction1=new Transaction(transferAmount,"transfer",account1);
					accountdao.updateTransaction(transaction1);
					accountdao.updateAccount(account2);
					Transaction transaction2=new Transaction(transferAmount,"transfer",account2);
					accountdao.updateTransaction(transaction2);
					return account2.getAccountBalance();
				}
				else
					throw new InvalidAmountException();

			}
			else throw new InsufficientBalanceException();
		}

		else throw new InvalidPinNumberException();
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException {
		Account account=accountdao.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException();
		else return account;
	}
	@Override
	public ArrayList<Account> getAllAccountDetails(){
		return accountdao.getAllAccountDetails();
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransaction(Account account) throws NoTransactionsFoundException {
		if(accountdao.getAccountAllTransactionDetails(account)!=null)
			return accountdao.getAccountAllTransactionDetails(account);
		else
			throw new NoTransactionsFoundException();
	}
	@Override
	public long openAccount(String accountType, float accountBalance,
			int pinNumber, int confirmPinNumber, String firstName,
			String lastName, long phoneNumber) throws InvalidAmountException {
		Account account=new Account(pinNumber, confirmPinNumber, firstName, lastName, phoneNumber, accountType, accountBalance);
		if(accountBalance>=1000){
			accountdao.saveAccountDetails(account);
			return account.getAccountNo();
		}
		else throw new InvalidAmountException();
	}
}
