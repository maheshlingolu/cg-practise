package com.cg.capbook.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SigninPage {
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-sign-in/div/form/table/tbody/tr[1]/th[2]/input")
	private WebElement email;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-sign-in/div/form/table/tbody/tr[2]/th[2]/input")
	private WebElement password;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-sign-in/div/form/table/tbody/tr[3]/th/input")
	private WebElement submit;
public SigninPage() {}
public String getEmail() {
	return email.getAttribute("value");
}
public void setEmail(String email) {
	this.email.sendKeys(email);
}
public String getPassword() {
	return password.getAttribute("value");
}
public void setPassword(String password) {
	this.password.sendKeys(password);
}
public void clickSignin() {
	submit.submit();
}
}
