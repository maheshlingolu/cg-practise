package com.cg.capbook.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SignupPage {
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[1]/th[2]/input")
	private WebElement firstName;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[2]/th[2]/input")
	private WebElement lastName;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[3]/th[2]/input")
	private WebElement email;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[4]/th[2]/input")
	private WebElement dateOfBirth;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[5]/th[2]/input")
	private WebElement mobileNo;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[6]/th[2]")
	private WebElement gender1;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[6]/th[2]/input[1]")
	private WebElement gender2;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[6]/th[2]/input[2]")
	private WebElement gender3;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[6]/th[2]/input[3]")
	private WebElement password;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[8]/th[2]/input")
	private WebElement confirmPassword;
	@FindBy(how=How.XPATH,xpath="/html/body/app-root/app-registration/div/form/table/tbody/tr[9]/th/input")
	private WebElement submit;
	public  SignupPage() {}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getEmail() {
		return email.getAttribute("value");
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
			}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public void selectMale() {
		gender1.click();
		}
	public void selectFemale() {
		gender2.click();
	}
	public void selectOther() {
		gender3.click();
	}
	public String getPassword() {
		return password.getAttribute("value");
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public String getConfirmPassword() {
		return confirmPassword.getAttribute("value");
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword.sendKeys(confirmPassword);
	}
	public void clickSignup() {
		submit.submit();
	}
		}
