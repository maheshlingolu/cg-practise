package com.cg.capbook.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.capbook.pagebeans.SignupPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class CapbookSignupStepDefinition {
	private WebDriver driver;
	private SignupPage signupPage;
	@Given("^User is in Capbook SignUp Page$")
	public void user_is_in_Capbook_SignUp_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4200/signUp");
		signupPage=PageFactory.initElements(driver, SignupPage.class);
	}
	@When("^User Enter enters valid details$")
	public void user_Enter_enters_valid_details() throws Throwable {
		signupPage.setFirstName("mahesh");
		signupPage.setLastName("lingolu");
		signupPage.setEmail("lingolumahesh@gmail.com");
		signupPage.setMobileNo("962960583");
		signupPage.setDateOfBirth("12/06/1997");
		signupPage.selectMale();
		signupPage.setPassword("ptjjren@143");
		signupPage.setConfirmPassword("ptjjren@143");
	}
	@When("^User clicks 'Sign up'$")
	public void user_clicks_Sign_up() throws Throwable {
		signupPage.clickSignup();
	}
	@Then("^User account should be created$")
	public void user_account_should_be_created() throws Throwable {
		String actualurl=driver.getCurrentUrl();
		String expectedurl="http://localhost:4200/signIn";
		Assert.assertEquals(expectedurl, actualurl);
		driver.close();
	}
	@Then("^Message should be displayed as Welcome 'userName'$")
	public void message_should_be_displayed_as_Welcome_userName() throws Throwable {
	}
	@When("^User do not few details$")
	public void user_do_not_few_details() throws Throwable {
	}
	@Then("^Message should be displayed as 'Fill all required details to create your account'$")
	public void message_should_be_displayed_as_Fill_all_required_details_to_create_your_account() throws Throwable {
		String actualurl=driver.getCurrentUrl();
		String expectedurl="http://localhost:4200/signUp";
		Assert.assertEquals(expectedurl, actualurl);
		driver.close();
	}
	@When("^User enters a password in password field$")
	public void user_enters_a_password_in_password_field() throws Throwable {
		signupPage.setFirstName("mahesh");
		signupPage.setLastName("lingolu");
		signupPage.setEmail("lingolumahesh@gmail.com");
		signupPage.setMobileNo("962960583");
		signupPage.setDateOfBirth("12/06/1997");
		signupPage.selectMale();
		signupPage.setPassword("ptjjren@143");
	}
	@When("^User enters different password in confirm password field$")
	public void user_enters_different_password_in_confirm_password_field() throws Throwable {
		signupPage.setConfirmPassword("ptjjren@123");
	}
	@Then("^Message should be displayed as 'Password Mismatch'$")
	public void message_should_be_displayed_as_Password_Mismatch() throws Throwable {
		String actualurl=driver.getCurrentUrl();
		String expectedurl="http://localhost:4200/signUp";
		Assert.assertEquals(expectedurl, actualurl);
		driver.close();
	}
}
