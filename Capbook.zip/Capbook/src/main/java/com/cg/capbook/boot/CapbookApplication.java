package com.cg.capbook.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages= {"com.cg.capbook"})
@EntityScan(basePackages="com.cg.capbook.beans")
@EnableJpaRepositories(basePackages="com.cg.capbook.daoservices")
public class CapbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapbookApplication.class, args);
	}
}
