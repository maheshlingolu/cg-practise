package com.cg.capbook.pagebeans;

public class SignupPage {

}
