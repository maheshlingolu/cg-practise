package com.cg.capbook.stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class CapbookSigninStepDefinition {
	@Given("^User is in Capbook Signin Page$")
	public void user_is_in_Capbook_Signin_Page() throws Throwable {
	   
	 
	}

	@When("^User enters valid credentials$")
	public void user_enters_valid_credentials() throws Throwable {
	   
	 
	}

	@When("^User clicks on 'Sign in'$")
	public void user_clicks_on_Sign_in() throws Throwable {
	   
	 
	}

	@Then("^User should Signin to his Capbook account$")
	public void user_should_Signin_to_his_Capbook_account() throws Throwable {
	   
	 
	}

	@When("^User enters correct user name wrong password$")
	public void user_enters_correct_user_name_wrong_password() throws Throwable {
	   
	 
	}

	@Then("^message should be displayed as \"([^\"]*)\"$")
	public void message_should_be_displayed_as(String arg1) throws Throwable {
	   
	 
	}

	@When("^User enters wrong user name Correct password$")
	public void user_enters_wrong_user_name_Correct_password() throws Throwable {
	   
	 
	}

}
