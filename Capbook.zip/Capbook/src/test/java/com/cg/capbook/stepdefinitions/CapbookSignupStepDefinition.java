package com.cg.capbook.stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class CapbookSignupStepDefinition {
	
	@Given("^User is in Capbook SignUp Page$")
	public void user_is_in_Capbook_SignUp_Page() throws Throwable {
		
		}

	@When("^User Enter enters valid details$")
	public void user_Enter_enters_valid_details() throws Throwable {
	
	   	}

	@When("^User clicks 'Sign up'$")
	public void user_clicks_Sign_up() throws Throwable {
	 
	    
	}

	@Then("^User account should be created$")
	public void user_account_should_be_created() throws Throwable {
	 
	    
	}

	@Then("^Message should be displayed as Welcome 'userName'$")
	public void message_should_be_displayed_as_Welcome_userName() throws Throwable {
	 
	    
	}

	@When("^User do not few details$")
	public void user_do_not_few_details() throws Throwable {
	 
	    
	}

	@Then("^Message should be displayed as 'Fill all required details to create your account'$")
	public void message_should_be_displayed_as_Fill_all_required_details_to_create_your_account() throws Throwable {
	 
	    
	}

	@When("^User enters a password in password field$")
	public void user_enters_a_password_in_password_field() throws Throwable {
	 
	    
	}

	@When("^User enters different password in confirm password field$")
	public void user_enters_different_password_in_confirm_password_field() throws Throwable {
	 
	    
	}

	@Then("^Message should be displayed as 'Password Mismatch'$")
	public void message_should_be_displayed_as_Password_Mismatch() throws Throwable {
	 
	    
	}


}
