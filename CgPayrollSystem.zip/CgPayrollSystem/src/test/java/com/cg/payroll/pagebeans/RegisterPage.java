package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterPage {
	@FindBy(how=How.NAME, name="firstName")
	private WebElement firstName;
	@FindBy(how=How.NAME, name="lastName")
	private WebElement lastName;
	@FindBy(how=How.NAME, name="department")
	private WebElement department;
	@FindBy(how=How.NAME, name="designation")
	private WebElement designation;
	@FindBy(how=How.NAME, name="pancard")
	private WebElement pancard;
	@FindBy(how=How.NAME, name="emailId")
	private WebElement emailId;
	@FindBy(how=How.NAME, name="yearlyInvestmentUnder80c")
	private WebElement yearlyInvestmentUnder80c;
	@FindBy(how=How.NAME, name="bankDetails.accountNumber")
	private WebElement accountNumber;
	@FindBy(how=How.NAME, name="bankDetails.bankName")
	private WebElement bankName;
	@FindBy(how=How.NAME, name="bankDetails.ifscCode")
	private WebElement ifscCode;
	@FindBy(how=How.NAME, name="salary.basicSalary")
	private WebElement basicSalary;
	@FindBy(how=How.NAME, name="submit")
	private WebElement submit;
	public RegisterPage() {
		super();
	}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getDepartment() {
		return department.getAttribute("value");
	}
	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}
	public String getDesignation() {
		return designation.getAttribute("value");
	}
	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}
	public String getPancard() {
		return pancard.getAttribute("value");
	}
	public void setPancard(String pancard) {
		this.pancard.sendKeys(pancard);
	}
	public String getEmailId() {
		return emailId.getAttribute("value");
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public String getYearlyInvestmentUnder80c() {
		return yearlyInvestmentUnder80c.getAttribute("value");
	}
	public void setYearlyInvestmentUnder80c(String yearlyInvestmentUnder80c) {
		this.yearlyInvestmentUnder80c.sendKeys(yearlyInvestmentUnder80c);
	}
	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber.sendKeys(accountNumber);
	}
	public String getBankName() {
		return bankName.getAttribute("value");
	}
	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}
	public String getIfscCode() {
		return ifscCode.getAttribute("value");
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode.sendKeys(ifscCode);
	}
	public String getBasicSalary() {
		return basicSalary.getAttribute("value");
	}
	public void setBasicSalary(String basicSalary) {
		this.basicSalary.sendKeys(basicSalary);
	}
	public String getSubmit() {
		return submit.getAttribute("value");
	}
	public void clickSubmit() {
		submit.click();
	}
}
